Pick-to-Pick File Transfer Utility

Pick-to-Pick transfer is implemented by the FTPICK program. Use FTPICK
for both the sending and receiving processes (select "S" or "R" for
"Send" or "Receive"). Selecting "D" (Direct transfer) requires two
AccuTerm/Windows sessions (one connected to the sending machine, the
other connected to the receiving machine). Once the receiver is started,
the sender may send multiple files. If you do not do a direct transfer,
you can send an intermediate file to the PC, and upload it later.



